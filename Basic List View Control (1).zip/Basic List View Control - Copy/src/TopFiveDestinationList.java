import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
            	topDestinationListFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(TopFiveDestinationList.class.getResource("/resources/globe.png")));
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);
        
        //Removed List adding panel to lay out buttons
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    
        panel.add(createButton("1. Bruges, Belgium - Beautiful, relaxed, and picturesque medieval city that will finally give you reason to visit Belgium.", new ImageIcon(getClass().getResource("/resources/Bruges.jpg"))));
        panel.add(createButton("2. Kyoto, Japan - With its ancient temples, traditional tea houses, and blooming cherry blossoms, Kyoto is the place to experience traditional Japan.", new ImageIcon(getClass().getResource("/resources/Kyoto.jpg"))));
        panel.add(createButton("3. Looking to get away from it all? Come to Lord Howe Island, far off the coast of Australia and see exotic birds, beautiful reefs, and cows.", new ImageIcon(getClass().getResource("/resources/LordHoweIsland.jpg"))));
        panel.add(createButton("4. How about some history with a dash of danger; step back in time to the ruins of Pompeii. Sure it erupted and destroyed everything around, but what are odds of it happening again? --Legal Disclaimer: Technically it's not extinct so there is a non-zero chance of it happening again.", new ImageIcon(getClass().getResource("/resources/Pompeii.jpg"))));
        panel.add(createButton("5. When you want to really get away from it all and disappear (legally), look no further than Alice Springs. You'll have all the time in the world to soak in the vast ....nothing. On the plus side, it makes for some of the best stargazing in the world, so pack a telescope!", new ImageIcon(getClass().getResource("/resources/AliceSprings.jpg"))));

        // Adding the panel to frame
        getContentPane().add(new JScrollPane(panel), BorderLayout.CENTER);
        
        //Adding label at the bottom
        JLabel nameLabel = new JLabel("Made by Daniel Collins", SwingConstants.CENTER);
        getContentPane().add(nameLabel, BorderLayout.SOUTH);
    }
    private JButton createButton(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        
        return button;
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}